

import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class Honeypot {
    private static int PORT;
    private static String LOG_FILE;
    private static Map<String, Long> connectionTimes = new ConcurrentHashMap<>();
    private static final long SCAN_THRESHOLD_MS = 1000; // 1 sec between requests = suspicious

    public static void main(String[] args) {
        loadConfig();
        System.out.println("🔥 Honeypot listening on port " + PORT + "...");

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            File logDir = new File("logs");
            if (!logDir.exists()) logDir.mkdirs();

            while (true) {
                Socket socket = serverSocket.accept();
                String attackerIP = socket.getInetAddress().getHostAddress();
                String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

                // Nmap / rapid scan detection
                boolean isScan = false;
                if (connectionTimes.containsKey(attackerIP)) {
                    long lastTime = connectionTimes.get(attackerIP);
                    long diff = System.currentTimeMillis() - lastTime;
                    if (diff < SCAN_THRESHOLD_MS) {
                        isScan = true;
                        logAndPrint(time + " | ⚠️ Nmap/Scan detected from: " + attackerIP);
                    }
                }
                connectionTimes.put(attackerIP, System.currentTimeMillis());

                // Read HTTP headers if any
                
                String deviceDetails = "";
                try {
                    BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    String line;
                    while (!(line = in.readLine()).isEmpty()) {
                        if (line.startsWith("User-Agent:")) {
                            deviceDetails = line.substring(11).trim();
                        }
                    }
                } catch (Exception e) {
                    deviceDetails = "Unknown";
                }

                logAndPrint(time + " | IP: " + attackerIP + " | Device: " + deviceDetails);
                
                
                // Serve fake HTML page
                try {
                    File htmlFile = new File("login.html");
                    BufferedReader br = new BufferedReader(new FileReader(htmlFile));
                    StringBuilder responseBuilder = new StringBuilder();
                    String htmlLine;
                    while ((htmlLine = br.readLine()) != null) {
                        responseBuilder.append(htmlLine).append("\n");
                    }
                    br.close();

                    String httpResponse = "HTTP/1.1 200 OK\r\n" +
                            "Content-Type: text/html\r\n\r\n" +
                            responseBuilder.toString();

                    socket.getOutputStream().write(httpResponse.getBytes("UTF-8"));
                } catch (Exception e) {
                    System.err.println("❌ Failed to send HTTP response: " + e.getMessage());
                }

                socket.close();
            }

        } catch (IOException e) {
            System.err.println("❌ Error: " + e.getMessage());
        }
    }

    private static void loadConfig() {
        try {
            Properties props = new Properties();
            FileInputStream in = new FileInputStream("config/config.txt");
            props.load(in);
            PORT = Integer.parseInt(props.getProperty("port"));
            LOG_FILE = props.getProperty("logfile");
            in.close();
        } catch (IOException e) {
            PORT = 2222;
            LOG_FILE = "logs/connections.log";
        }
    }

    private static void logAndPrint(String data) {
        System.out.println(data);
        try (FileWriter fw = new FileWriter(LOG_FILE, true);
             BufferedWriter bw = new BufferedWriter(fw);
             PrintWriter out = new PrintWriter(bw)) {
            out.println(data);
        } catch (IOException e) {
            System.err.println("❌ Log write failed: " + e.getMessage());
        }
    }
}

